"""
Shared pytest fixtures.
Each test gets a fresh isolated SQLite database via a temp file.
"""
import os
import tempfile
import pytest


@pytest.fixture(scope="function")
def app(monkeypatch):
    """Create a fresh app instance with an isolated temp database per test."""
    db_fd, db_path = tempfile.mkstemp(suffix=".db")

    # Patch DB_PATH before app module loads db
    monkeypatch.setenv("DB_PATH", db_path)

    import app.db as db_module
    monkeypatch.setattr(db_module, "DB_PATH", db_path)

    from app import create_app
    application = create_app({
        "TESTING": True,
        "JWT_SECRET_KEY": "test-secret-key",
    })

    yield application

    os.close(db_fd)
    os.unlink(db_path)


@pytest.fixture(scope="function")
def client(app):
    return app.test_client()


@pytest.fixture(scope="function")
def admin_token(client):
    resp = client.post("/api/auth/login", json={
        "email": "admin@finance.local",
        "password": "admin123",
    })
    return resp.get_json()["token"]


@pytest.fixture(scope="function")
def viewer_token(client, admin_token):
    client.post("/api/users/", json={
        "name": "Test Viewer", "email": "viewer@test.com",
        "password": "pass123", "role": "viewer",
    }, headers={"Authorization": f"Bearer {admin_token}"})
    resp = client.post("/api/auth/login", json={"email": "viewer@test.com", "password": "pass123"})
    return resp.get_json()["token"]


@pytest.fixture(scope="function")
def analyst_token(client, admin_token):
    client.post("/api/users/", json={
        "name": "Test Analyst", "email": "analyst@test.com",
        "password": "pass123", "role": "analyst",
    }, headers={"Authorization": f"Bearer {admin_token}"})
    resp = client.post("/api/auth/login", json={"email": "analyst@test.com", "password": "pass123"})
    return resp.get_json()["token"]
