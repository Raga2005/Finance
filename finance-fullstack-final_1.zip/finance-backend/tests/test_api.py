"""
Integration tests for the Finance Dashboard API.

Covers:
  - Authentication (login, register, /me)
  - Role-based access control (viewer / analyst / admin)
  - Financial records CRUD, filtering, search, pagination, soft delete
  - Dashboard analytics (summary, by-category, trends, recent, weekly)
  - User management (create, update role/name, deactivate)

Fixtures are defined in conftest.py.
Run with: python -m pytest tests/ -v
"""

# ── Auth tests ─────────────────────────────────────────────────────────────────

class TestAuth:
    def test_login_success(self, client):
        resp = client.post("/api/auth/login", json={
            "email": "admin@finance.local", "password": "admin123",
        })
        assert resp.status_code == 200
        data = resp.get_json()
        assert "token" in data
        assert data["user"]["role"] == "admin"

    def test_login_wrong_password(self, client):
        resp = client.post("/api/auth/login", json={
            "email": "admin@finance.local", "password": "wrong",
        })
        assert resp.status_code == 401

    def test_login_unknown_email(self, client):
        resp = client.post("/api/auth/login", json={
            "email": "nobody@test.com", "password": "pass123",
        })
        assert resp.status_code == 401

    def test_login_missing_password_field(self, client):
        resp = client.post("/api/auth/login", json={"email": "admin@finance.local"})
        assert resp.status_code == 422
        assert "password" in resp.get_json()["details"]

    def test_login_empty_body(self, client):
        resp = client.post("/api/auth/login", json={})
        assert resp.status_code == 422

    def test_register_viewer_success(self, client):
        resp = client.post("/api/auth/register", json={
            "name": "Jane Doe", "email": "jane@test.com",
            "password": "pass123", "role": "viewer",
        })
        assert resp.status_code == 201
        assert resp.get_json()["user"]["role"] == "viewer"
        assert "token" in resp.get_json()

    def test_register_admin_role_forbidden(self, client):
        """Public self-registration must not allow privileged roles."""
        resp = client.post("/api/auth/register", json={
            "name": "Sneaky", "email": "sneak@test.com",
            "password": "pass123", "role": "admin",
        })
        assert resp.status_code == 403

    def test_register_analyst_role_forbidden(self, client):
        resp = client.post("/api/auth/register", json={
            "name": "Sneaky2", "email": "sneak2@test.com",
            "password": "pass123", "role": "analyst",
        })
        assert resp.status_code == 403

    def test_register_duplicate_email(self, client):
        resp = client.post("/api/auth/register", json={
            "name": "Dup", "email": "admin@finance.local",
            "password": "pass123", "role": "viewer",
        })
        assert resp.status_code == 409

    def test_register_short_password_rejected(self, client):
        resp = client.post("/api/auth/register", json={
            "name": "Test", "email": "short@test.com",
            "password": "abc", "role": "viewer",
        })
        assert resp.status_code == 422
        assert "password" in resp.get_json()["details"]

    def test_me_returns_current_user(self, client, admin_token):
        resp = client.get("/api/auth/me", headers={"Authorization": f"Bearer {admin_token}"})
        assert resp.status_code == 200
        assert resp.get_json()["user"]["role"] == "admin"

    def test_me_no_token_returns_401(self, client):
        assert client.get("/api/auth/me").status_code == 401

    def test_me_invalid_token_returns_401(self, client):
        resp = client.get("/api/auth/me", headers={"Authorization": "Bearer bad.token.here"})
        assert resp.status_code == 401


# ── Access control tests ───────────────────────────────────────────────────────

class TestAccessControl:
    """Verifies that role boundaries are enforced at every route."""

    def test_viewer_cannot_create_record(self, client, viewer_token):
        resp = client.post("/api/records/", json={
            "amount": 100, "type": "income", "category": "X", "date": "2024-01-15",
        }, headers={"Authorization": f"Bearer {viewer_token}"})
        assert resp.status_code == 403

    def test_analyst_cannot_create_record(self, client, analyst_token):
        resp = client.post("/api/records/", json={
            "amount": 100, "type": "income", "category": "X", "date": "2024-01-15",
        }, headers={"Authorization": f"Bearer {analyst_token}"})
        assert resp.status_code == 403

    def test_viewer_cannot_delete_record(self, client, admin_token, viewer_token):
        rid = client.post("/api/records/", json={
            "amount": 100, "type": "income", "category": "T", "date": "2024-01-01",
        }, headers={"Authorization": f"Bearer {admin_token}"}).get_json()["record"]["id"]
        resp = client.delete(f"/api/records/{rid}",
                             headers={"Authorization": f"Bearer {viewer_token}"})
        assert resp.status_code == 403

    def test_viewer_cannot_update_record(self, client, admin_token, viewer_token):
        rid = client.post("/api/records/", json={
            "amount": 100, "type": "income", "category": "T", "date": "2024-01-01",
        }, headers={"Authorization": f"Bearer {admin_token}"}).get_json()["record"]["id"]
        resp = client.patch(f"/api/records/{rid}",
                            json={"amount": 999},
                            headers={"Authorization": f"Bearer {viewer_token}"})
        assert resp.status_code == 403

    def test_viewer_cannot_list_users(self, client, viewer_token):
        assert client.get("/api/users/", headers={"Authorization": f"Bearer {viewer_token}"}).status_code == 403

    def test_analyst_cannot_list_users(self, client, analyst_token):
        assert client.get("/api/users/", headers={"Authorization": f"Bearer {analyst_token}"}).status_code == 403

    def test_viewer_cannot_access_monthly_trends(self, client, viewer_token):
        resp = client.get("/api/dashboard/monthly-trends",
                          headers={"Authorization": f"Bearer {viewer_token}"})
        assert resp.status_code == 403

    def test_analyst_can_access_monthly_trends(self, client, analyst_token):
        assert client.get("/api/dashboard/monthly-trends",
                          headers={"Authorization": f"Bearer {analyst_token}"}).status_code == 200

    def test_viewer_can_read_records(self, client, admin_token, viewer_token):
        client.post("/api/records/", json={
            "amount": 500, "type": "income", "category": "Salary", "date": "2024-03-01",
        }, headers={"Authorization": f"Bearer {admin_token}"})
        assert client.get("/api/records/",
                          headers={"Authorization": f"Bearer {viewer_token}"}).status_code == 200

    def test_viewer_can_access_summary(self, client, viewer_token):
        assert client.get("/api/dashboard/summary",
                          headers={"Authorization": f"Bearer {viewer_token}"}).status_code == 200

    def test_admin_can_list_users(self, client, admin_token):
        assert client.get("/api/users/",
                          headers={"Authorization": f"Bearer {admin_token}"}).status_code == 200

    def test_unauthenticated_denied_on_all_routes(self, client):
        for method, url in [
            ("GET", "/api/records/"),
            ("GET", "/api/users/"),
            ("GET", "/api/dashboard/summary"),
            ("GET", "/api/dashboard/by-category"),
            ("GET", "/api/dashboard/recent"),
            ("GET", "/api/auth/me"),
        ]:
            resp = client.open(url, method=method)
            assert resp.status_code == 401, f"Expected 401 for {method} {url}"

    def test_inactive_user_cannot_login(self, client, admin_token):
        user_id = client.post("/api/users/", json={
            "name": "Gone", "email": "gone@test.com",
            "password": "pass123", "role": "viewer",
        }, headers={"Authorization": f"Bearer {admin_token}"}).get_json()["user"]["id"]
        client.delete(f"/api/users/{user_id}",
                      headers={"Authorization": f"Bearer {admin_token}"})
        resp = client.post("/api/auth/login", json={"email": "gone@test.com", "password": "pass123"})
        assert resp.status_code == 403


# ── Records CRUD tests ─────────────────────────────────────────────────────────

class TestRecords:
    def _make(self, client, token, **overrides):
        payload = {"amount": 500.0, "type": "income",
                   "category": "Salary", "date": "2024-03-01", "notes": "March"}
        payload.update(overrides)
        return client.post("/api/records/", json=payload,
                           headers={"Authorization": f"Bearer {token}"})

    # ── Create
    def test_create_success(self, client, admin_token):
        resp = self._make(client, admin_token)
        assert resp.status_code == 201
        r = resp.get_json()["record"]
        assert r["amount"] == 500.0 and r["type"] == "income" and r["is_deleted"] == 0

    def test_create_zero_amount_rejected(self, client, admin_token):
        assert self._make(client, admin_token, amount=0).status_code == 422

    def test_create_negative_amount_rejected(self, client, admin_token):
        assert self._make(client, admin_token, amount=-100).status_code == 422

    def test_create_invalid_type_rejected(self, client, admin_token):
        resp = self._make(client, admin_token, type="transfer")
        assert resp.status_code == 422
        assert "type" in resp.get_json()["details"]

    def test_create_bad_date_format_rejected(self, client, admin_token):
        resp = self._make(client, admin_token, date="01-03-2024")
        assert resp.status_code == 422
        assert "date" in resp.get_json()["details"]

    def test_create_missing_all_fields(self, client, admin_token):
        resp = client.post("/api/records/", json={},
                           headers={"Authorization": f"Bearer {admin_token}"})
        assert resp.status_code == 422
        details = resp.get_json()["details"]
        for f in ("amount", "type", "category", "date"):
            assert f in details, f"Missing error for field: {f}"

    # ── Read
    def test_get_single_record(self, client, admin_token):
        rid = self._make(client, admin_token).get_json()["record"]["id"]
        resp = client.get(f"/api/records/{rid}",
                          headers={"Authorization": f"Bearer {admin_token}"})
        assert resp.status_code == 200 and resp.get_json()["record"]["id"] == rid

    def test_get_nonexistent_returns_404(self, client, admin_token):
        assert client.get("/api/records/no-such-id",
                          headers={"Authorization": f"Bearer {admin_token}"}).status_code == 404

    # ── Filtering
    def test_filter_by_type(self, client, admin_token):
        self._make(client, admin_token, type="income", category="Sales")
        self._make(client, admin_token, type="expense", category="Rent")
        records = client.get("/api/records/?type=income",
                             headers={"Authorization": f"Bearer {admin_token}"}).get_json()["records"]
        assert all(r["type"] == "income" for r in records)

    def test_filter_by_category(self, client, admin_token):
        self._make(client, admin_token, category="Consulting")
        self._make(client, admin_token, category="Rent")
        records = client.get("/api/records/?category=Consulting",
                             headers={"Authorization": f"Bearer {admin_token}"}).get_json()["records"]
        assert all(r["category"].lower() == "consulting" for r in records)

    def test_filter_by_date_range(self, client, admin_token):
        self._make(client, admin_token, date="2024-01-10")
        self._make(client, admin_token, date="2024-06-10")
        records = client.get("/api/records/?date_from=2024-06-01&date_to=2024-12-31",
                             headers={"Authorization": f"Bearer {admin_token}"}).get_json()["records"]
        assert all(r["date"] >= "2024-06-01" for r in records)

    def test_filter_invalid_date_range_rejected(self, client, admin_token):
        resp = client.get("/api/records/?date_from=2024-12-01&date_to=2024-01-01",
                          headers={"Authorization": f"Bearer {admin_token}"})
        assert resp.status_code == 422

    def test_search_by_category_keyword(self, client, admin_token):
        self._make(client, admin_token, category="Freelance Design")
        self._make(client, admin_token, category="Groceries")
        records = client.get("/api/records/?search=freelance",
                             headers={"Authorization": f"Bearer {admin_token}"}).get_json()["records"]
        assert len(records) >= 1
        assert all("freelance" in r["category"].lower() for r in records)

    def test_search_by_notes_keyword(self, client, admin_token):
        self._make(client, admin_token, notes="Payment from Acme Corp")
        self._make(client, admin_token, notes="Monthly gym")
        records = client.get("/api/records/?search=acme",
                             headers={"Authorization": f"Bearer {admin_token}"}).get_json()["records"]
        assert len(records) >= 1

    # ── Pagination
    def test_pagination_limits_results(self, client, admin_token):
        for i in range(6):
            self._make(client, admin_token, amount=i + 10)
        data = client.get("/api/records/?page=1&per_page=3",
                          headers={"Authorization": f"Bearer {admin_token}"}).get_json()
        assert len(data["records"]) == 3 and data["pagination"]["per_page"] == 3

    def test_pagination_pages_do_not_overlap(self, client, admin_token):
        for i in range(5):
            self._make(client, admin_token, amount=i + 100)
        p1_ids = {r["id"] for r in client.get("/api/records/?page=1&per_page=3",
                  headers={"Authorization": f"Bearer {admin_token}"}).get_json()["records"]}
        p2_ids = {r["id"] for r in client.get("/api/records/?page=2&per_page=3",
                  headers={"Authorization": f"Bearer {admin_token}"}).get_json()["records"]}
        assert p1_ids.isdisjoint(p2_ids)

    # ── Update
    def test_update_amount(self, client, admin_token):
        rid = self._make(client, admin_token).get_json()["record"]["id"]
        resp = client.patch(f"/api/records/{rid}", json={"amount": 999.99},
                            headers={"Authorization": f"Bearer {admin_token}"})
        assert resp.status_code == 200 and resp.get_json()["record"]["amount"] == 999.99

    def test_update_multiple_fields(self, client, admin_token):
        rid = self._make(client, admin_token).get_json()["record"]["id"]
        resp = client.patch(f"/api/records/{rid}",
                            json={"category": "Consulting", "notes": "Revised"},
                            headers={"Authorization": f"Bearer {admin_token}"})
        r = resp.get_json()["record"]
        assert r["category"] == "Consulting" and r["notes"] == "Revised"

    def test_update_nonexistent_returns_404(self, client, admin_token):
        assert client.patch("/api/records/no-such-id", json={"amount": 100},
                            headers={"Authorization": f"Bearer {admin_token}"}).status_code == 404

    def test_update_empty_body_rejected(self, client, admin_token):
        rid = self._make(client, admin_token).get_json()["record"]["id"]
        assert client.patch(f"/api/records/{rid}", json={},
                            headers={"Authorization": f"Bearer {admin_token}"}).status_code == 400

    # ── Soft delete
    def test_soft_delete_hides_record(self, client, admin_token):
        rid = self._make(client, admin_token).get_json()["record"]["id"]
        assert client.delete(f"/api/records/{rid}",
                             headers={"Authorization": f"Bearer {admin_token}"}).status_code == 200
        ids = [r["id"] for r in client.get("/api/records/",
               headers={"Authorization": f"Bearer {admin_token}"}).get_json()["records"]]
        assert rid not in ids

    def test_soft_delete_get_returns_404(self, client, admin_token):
        rid = self._make(client, admin_token).get_json()["record"]["id"]
        client.delete(f"/api/records/{rid}", headers={"Authorization": f"Bearer {admin_token}"})
        assert client.get(f"/api/records/{rid}",
                          headers={"Authorization": f"Bearer {admin_token}"}).status_code == 404

    def test_delete_already_deleted_returns_404(self, client, admin_token):
        rid = self._make(client, admin_token).get_json()["record"]["id"]
        client.delete(f"/api/records/{rid}", headers={"Authorization": f"Bearer {admin_token}"})
        assert client.delete(f"/api/records/{rid}",
                             headers={"Authorization": f"Bearer {admin_token}"}).status_code == 404

    # ── Categories
    def test_list_categories(self, client, admin_token):
        self._make(client, admin_token, category="Rent")
        self._make(client, admin_token, category="Salary")
        cats = client.get("/api/records/categories",
                          headers={"Authorization": f"Bearer {admin_token}"}).get_json()["categories"]
        assert "Rent" in cats and "Salary" in cats


# ── Dashboard analytics tests ──────────────────────────────────────────────────

class TestDashboard:
    def _seed(self, client, token):
        for r in [
            {"amount": 3000.0, "type": "income",  "category": "Salary",    "date": "2024-03-01"},
            {"amount": 1200.0, "type": "expense",  "category": "Rent",      "date": "2024-03-05"},
            {"amount": 200.0,  "type": "expense",  "category": "Groceries", "date": "2024-03-10"},
            {"amount": 500.0,  "type": "income",   "category": "Freelance", "date": "2024-03-15"},
        ]:
            client.post("/api/records/", json=r,
                        headers={"Authorization": f"Bearer {token}"})

    def test_summary_totals(self, client, admin_token):
        self._seed(client, admin_token)
        s = client.get("/api/dashboard/summary",
                       headers={"Authorization": f"Bearer {admin_token}"}).get_json()["summary"]
        assert s["total_income"] == 3500.0
        assert s["total_expenses"] == 1400.0
        assert s["net_balance"] == 2100.0
        assert s["record_count"] == 4

    def test_summary_empty_database(self, client, admin_token):
        s = client.get("/api/dashboard/summary",
                       headers={"Authorization": f"Bearer {admin_token}"}).get_json()["summary"]
        assert s["total_income"] == 0.0
        assert s["net_balance"] == 0.0

    def test_summary_date_filter(self, client, admin_token):
        self._seed(client, admin_token)
        s = client.get("/api/dashboard/summary?date_from=2024-03-01&date_to=2024-03-01",
                       headers={"Authorization": f"Bearer {admin_token}"}).get_json()["summary"]
        assert s["total_income"] == 3000.0 and s["record_count"] == 1

    def test_by_category_breakdown(self, client, admin_token):
        self._seed(client, admin_token)
        cats = {c["category"]: c for c in client.get(
            "/api/dashboard/by-category",
            headers={"Authorization": f"Bearer {admin_token}"}
        ).get_json()["by_category"]}
        assert cats["Rent"]["expense"] == 1200.0
        assert cats["Salary"]["income"] == 3000.0

    def test_recent_activity_limit(self, client, admin_token):
        self._seed(client, admin_token)
        recent = client.get("/api/dashboard/recent?limit=2",
                            headers={"Authorization": f"Bearer {admin_token}"}).get_json()["recent"]
        assert len(recent) == 2

    def test_weekly_summary_structure(self, client, admin_token):
        data = client.get("/api/dashboard/weekly-summary",
                          headers={"Authorization": f"Bearer {admin_token}"}).get_json()
        assert "weekly_summary" in data

    def test_monthly_trends_fields(self, client, admin_token):
        data = client.get("/api/dashboard/monthly-trends?months=6",
                          headers={"Authorization": f"Bearer {admin_token}"}).get_json()
        assert data["months_requested"] == 6
        for entry in data["monthly_trends"]:
            assert all(k in entry for k in ("month", "income", "expenses", "net", "transactions"))

    def test_monthly_trends_analyst_allowed(self, client, analyst_token):
        assert client.get("/api/dashboard/monthly-trends",
                          headers={"Authorization": f"Bearer {analyst_token}"}).status_code == 200

    def test_monthly_trends_viewer_forbidden(self, client, viewer_token):
        assert client.get("/api/dashboard/monthly-trends",
                          headers={"Authorization": f"Bearer {viewer_token}"}).status_code == 403


# ── User management tests ──────────────────────────────────────────────────────

class TestUsers:
    def _create(self, client, token, **kw):
        payload = {"name": "Test", "email": "t@t.com", "password": "pass123", "role": "viewer"}
        payload.update(kw)
        return client.post("/api/users/", json=payload,
                           headers={"Authorization": f"Bearer {token}"})

    def test_admin_creates_any_role(self, client, admin_token):
        for role in ("viewer", "analyst", "admin"):
            resp = self._create(client, admin_token,
                                email=f"{role}x@test.com", role=role, name=f"U {role}")
            assert resp.status_code == 201 and resp.get_json()["user"]["role"] == role

    def test_duplicate_email_rejected(self, client, admin_token):
        self._create(client, admin_token, email="dup@test.com")
        assert self._create(client, admin_token, email="dup@test.com").status_code == 409

    def test_list_users_paginated(self, client, admin_token):
        data = client.get("/api/users/?per_page=1",
                          headers={"Authorization": f"Bearer {admin_token}"}).get_json()
        assert len(data["users"]) == 1 and "pagination" in data

    def test_get_single_user(self, client, admin_token):
        user_id = self._create(client, admin_token,
                               email="solo@test.com").get_json()["user"]["id"]
        resp = client.get(f"/api/users/{user_id}",
                          headers={"Authorization": f"Bearer {admin_token}"})
        assert resp.status_code == 200

    def test_update_user_role(self, client, admin_token):
        user_id = self._create(client, admin_token,
                               email="role@test.com", role="viewer").get_json()["user"]["id"]
        resp = client.patch(f"/api/users/{user_id}", json={"role": "analyst"},
                            headers={"Authorization": f"Bearer {admin_token}"})
        assert resp.status_code == 200 and resp.get_json()["user"]["role"] == "analyst"

    def test_update_user_name(self, client, admin_token):
        user_id = self._create(client, admin_token,
                               name="Old", email="nm@test.com").get_json()["user"]["id"]
        resp = client.patch(f"/api/users/{user_id}", json={"name": "New Name"},
                            headers={"Authorization": f"Bearer {admin_token}"})
        assert resp.get_json()["user"]["name"] == "New Name"

    def test_deactivate_user(self, client, admin_token):
        user_id = self._create(client, admin_token,
                               email="deac@test.com").get_json()["user"]["id"]
        assert client.delete(f"/api/users/{user_id}",
                             headers={"Authorization": f"Bearer {admin_token}"}).status_code == 200
        u = client.get(f"/api/users/{user_id}",
                       headers={"Authorization": f"Bearer {admin_token}"}).get_json()["user"]
        assert u["is_active"] == 0

    def test_deactivated_user_cannot_login(self, client, admin_token):
        user_id = self._create(client, admin_token,
                               email="bye@test.com").get_json()["user"]["id"]
        client.delete(f"/api/users/{user_id}",
                      headers={"Authorization": f"Bearer {admin_token}"})
        assert client.post("/api/auth/login",
                           json={"email": "bye@test.com", "password": "pass123"}).status_code == 403

    def test_update_nonexistent_returns_404(self, client, admin_token):
        assert client.patch("/api/users/no-id", json={"role": "viewer"},
                            headers={"Authorization": f"Bearer {admin_token}"}).status_code == 404

    def test_get_nonexistent_returns_404(self, client, admin_token):
        assert client.get("/api/users/no-id",
                          headers={"Authorization": f"Bearer {admin_token}"}).status_code == 404

    def test_update_invalid_role_rejected(self, client, admin_token):
        user_id = self._create(client, admin_token,
                               email="inv@test.com").get_json()["user"]["id"]
        assert client.patch(f"/api/users/{user_id}", json={"role": "superadmin"},
                            headers={"Authorization": f"Bearer {admin_token}"}).status_code == 422
