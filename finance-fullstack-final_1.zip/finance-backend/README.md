# Finance Dashboard Backend

A RESTful backend for a multi-role finance dashboard. Supports financial record management, role-based access control, and aggregated analytics APIs.

> See `ASSUMPTIONS.md` for the reasoning behind design decisions.

---

## Tech Stack

| Layer | Choice |
|---|---|
| Language | Python 3.10+ |
| Framework | Flask |
| Database | SQLite (via built-in sqlite3 — zero extra setup) |
| Auth | JWT (flask-jwt-extended) |
| Password hashing | bcrypt |
| CORS | flask-cors |
| Tests | pytest — 70 integration tests |

---

## Project Structure

```
finance-backend/
├── app/
│   ├── __init__.py            # App factory (create_app)
│   ├── db.py                  # DB connection, schema creation, auto-seed admin
│   ├── middleware/
│   │   └── auth.py            # @require_role and @require_min_role decorators
│   ├── validators/
│   │   └── __init__.py        # Input validation — returns field-level error dicts
│   ├── routes/
│   │   ├── auth.py            # POST /login, /register, GET /me
│   │   ├── users.py           # Admin-only user management
│   │   ├── records.py         # CRUD + filter + search + pagination
│   │   └── dashboard.py       # Summary, category, trends, recent, weekly
│   └── utils/
│       └── error_handlers.py  # Centralised HTTP error responses
├── tests/
│   ├── conftest.py            # Shared fixtures (isolated temp DB per test)
│   └── test_api.py            # 70 integration tests
├── frontend/
│   └── index.html             # Complete single-file dashboard UI
├── run.py                     # Entry point
├── requirements.txt
├── README.md
└── ASSUMPTIONS.md             # Design decisions and reasoning
```

---

## Setup

```bash
# 1. Clone and enter the project
git clone <repo-url>
cd finance-backend

# 2. Create a virtual environment
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. (Optional) configure via environment variables
export JWT_SECRET_KEY="change-this-in-production"
export DB_PATH="finance.db"     # defaults to finance.db in the cwd

# 5. Run the server
python run.py
# Server starts at http://127.0.0.1:5000
```

A default admin account is created automatically on first run:

| Field | Value |
|---|---|
| Email | admin@finance.local |
| Password | admin123 |

---

## Frontend

Open `frontend/index.html` directly in a browser after starting the backend. No build step required.

Includes: login screen, KPI cards, monthly trend bar chart (analyst+), recent activity feed, category breakdown, records table with type/date/search filters and pagination, add/edit/delete modals (admin only), user management page (admin only).

---

## Running Tests

```bash
python -m pytest tests/ -v
```

70 tests covering authentication, role enforcement on every route, all record CRUD operations, search, filtering, pagination, soft delete, analytics accuracy, and user management. Every test runs against its own isolated temporary database.

---

## Roles and Permissions

| Action | viewer | analyst | admin |
|---|:---:|:---:|:---:|
| Login / register | ✓ | ✓ | ✓ |
| View records | ✓ | ✓ | ✓ |
| Search and filter records | ✓ | ✓ | ✓ |
| Dashboard summary | ✓ | ✓ | ✓ |
| Category breakdown | ✓ | ✓ | ✓ |
| Recent activity | ✓ | ✓ | ✓ |
| Weekly summary | ✓ | ✓ | ✓ |
| Monthly trends | ✗ | ✓ | ✓ |
| Create / update / delete records | ✗ | ✗ | ✓ |
| Manage users | ✗ | ✗ | ✓ |

Access control is enforced via decorators in `app/middleware/auth.py`. No role logic leaks into routes or business code.

---

## API Reference

All protected routes require: `Authorization: Bearer <token>`

### Auth

#### POST /api/auth/register
Public. Creates a viewer account only — admin and analyst accounts must be created by an admin via `/api/users/`.
```json
{ "name": "Jane Doe", "email": "jane@example.com", "password": "secure123" }
// 201 → { "token": "...", "user": { "id": "...", "role": "viewer" } }
```

#### POST /api/auth/login
```json
{ "email": "admin@finance.local", "password": "admin123" }
// 200 → { "token": "...", "user": { "id": "...", "role": "admin" } }
```

#### GET /api/auth/me
Returns the currently authenticated user's profile.

---

### Users (admin only)

| Method | Path | Description |
|---|---|---|
| GET | `/api/users/` | List all users — supports `?page=&per_page=` |
| POST | `/api/users/` | Create a user with any role |
| GET | `/api/users/:id` | Get a single user |
| PATCH | `/api/users/:id` | Update name, role, or active status |
| DELETE | `/api/users/:id` | Soft-deactivate the account |

PATCH fields (all optional): `name`, `role`, `is_active`

---

### Financial Records

| Method | Path | Min role | Description |
|---|---|---|---|
| GET | `/api/records/` | viewer | List with filters and pagination |
| GET | `/api/records/:id` | viewer | Get a single record |
| POST | `/api/records/` | admin | Create a record |
| PATCH | `/api/records/:id` | admin | Partial update |
| DELETE | `/api/records/:id` | admin | Soft delete |
| GET | `/api/records/categories` | viewer | List distinct categories |

**Filter / search query params:**

| Param | Description |
|---|---|
| `type` | `income` or `expense` |
| `category` | Case-insensitive exact match |
| `search` | Partial keyword match on category or notes |
| `date_from` | YYYY-MM-DD start of range |
| `date_to` | YYYY-MM-DD end of range |
| `page` | Page number (default 1) |
| `per_page` | Results per page (default 20, max 100) |

**POST/PATCH body:**
```json
{ "amount": 2500.00, "type": "income", "category": "Consulting", "date": "2024-03-15", "notes": "Optional" }
```

---

### Dashboard

| Endpoint | Min role | Description |
|---|---|---|
| GET /api/dashboard/summary | viewer | Total income, expenses, net balance, count |
| GET /api/dashboard/by-category | viewer | Income and expense per category |
| GET /api/dashboard/recent | viewer | Most recent N records (`?limit=10`) |
| GET /api/dashboard/weekly-summary | viewer | Income vs expenses last 4 weeks |
| GET /api/dashboard/monthly-trends | analyst | Monthly totals (`?months=12`, max 36) |

Summary and by-category support `?date_from=&date_to=` filtering.

**Summary response:**
```json
{ "summary": { "total_income": 12500.00, "total_expenses": 4300.00, "net_balance": 8200.00, "record_count": 18 } }
```

**Monthly trends response:**
```json
{ "monthly_trends": [{ "month": "2024-01", "income": 3000.0, "expenses": 1100.0, "net": 1900.0, "transactions": 5 }], "months_requested": 12 }
```

---

## Error Responses

All errors use a consistent format:

```json
{ "error": "Validation failed", "details": { "amount": ["Amount must be greater than 0"] } }
{ "error": "Record not found" }
{ "error": "Forbidden", "detail": "This action requires one of: admin" }
{ "error": "Authentication required", "detail": "Provide a Bearer token" }
```

---

## Optional Enhancements Included

- JWT authentication + bcrypt password hashing
- Pagination on all list endpoints
- Keyword search on records (category and notes fields)
- Filtering by type, category, date range
- Soft delete for both records and users
- 70 integration tests with isolated database per test
- Field-level validation errors
- DB indexes on frequently filtered columns
- CORS enabled for frontend integration
- Complete single-file frontend
