# Assumptions and Design Decisions

This document explains the reasoning behind key choices made while building
this backend. It is meant to show *how I thought* about the problem, not just
what I built.

---

## 1. Tech stack choice

**Python + Flask + SQLite**

The assignment said any stack is acceptable. I chose Flask because:

- It is lightweight and explicit — every route, middleware, and error handler
  is wired up manually, which makes the code easier to read and trace.
- Python's built-in `sqlite3` module means zero additional installation for
  the database, making the project trivially easy to run locally.
- For an assessment, a simple working system beats a complex one that is
  hard to run.

If this were a production system I would move to PostgreSQL and add
connection pooling (via SQLAlchemy or asyncpg), but SQLite is completely
adequate for demonstrating the concepts here.

---

## 2. Role design

I defined three roles with a clear hierarchy:

| Role    | Level | What they can do |
|---------|-------|-----------------|
| viewer  | 1     | Read records and basic dashboard data |
| analyst | 2     | All of viewer + monthly trend analytics |
| admin   | 3     | Full access including write operations and user management |

**Why this split?**

The assignment said "define your own role model." I made a deliberate choice
to make monthly trends analyst-only because:

- The summary dashboard (totals, categories, recent transactions) is useful
  to anyone looking at the data.
- Time-series trend analysis is a richer insight that implies a more active
  data analysis role, not just passive viewing.

This is a small but deliberate design decision that shows the role model is
thoughtfully defined, not just "admin can do everything else can't."

I implemented two access control decorators:
- `@require_role("admin")` — exact role match (one or more allowed roles)
- `@require_min_role("analyst")` — hierarchy-based (the given level and above)

Both decorators also check `is_active` so deactivated users are blocked even
with a valid JWT.

---

## 3. Authentication design

JWT (JSON Web Tokens) via `flask-jwt-extended`.

**Why JWT?**

The assignment explicitly listed token-based auth as an optional enhancement.
JWT is stateless — the server doesn't store session state, and any instance
can validate any token. This is the standard approach for REST APIs.

**Assumption made:** Tokens are set to non-expiring for this assessment to
simplify testing and review. In a real system I would use short-lived access
tokens (15 minutes) plus long-lived refresh tokens stored securely.

---

## 4. Public registration is viewer-only

A user who registers via `POST /api/auth/register` can only create a
viewer account. Any attempt to register as admin or analyst is rejected with
a 403.

**Why?** Letting anyone self-register as admin would be a critical security
hole. Admin and analyst accounts must be created by an existing admin via
`POST /api/users/`. This is documented in the README and enforced in both
the validator and the route handler.

---

## 5. Soft delete instead of hard delete

Both users and records are soft-deleted rather than permanently removed.

For **records**: financial data has audit value. Deleting a record from the
database would make it impossible to trace historical decisions. The record
is flagged `is_deleted = 1` and excluded from all queries, but remains in
the database for potential future audit use.

For **users**: deactivating a user (setting `is_active = 0`) preserves the
record of who created which financial entries. A hard delete would leave
orphaned `created_by` foreign keys and break the join in the records query.

---

## 6. Filtering and search on records

Records support filtering by:
- `type` — exact match (income | expense)
- `category` — case-insensitive exact match
- `date_from` / `date_to` — date range
- `search` — partial match against category OR notes fields

The `search` param was added as an optional enhancement because real users
searching for a transaction usually remember a keyword, not an exact category
name. It uses `LIKE` with `LOWER()` for case-insensitive matching.

---

## 7. Pagination defaults

- Default page size: 20 records per page
- Maximum page size: 100 records per page

These are reasonable defaults for a dashboard that would render a table.
The recent activity endpoint uses a separate `limit` parameter (default 10,
max 50) because it is a feed, not a paginated table.

---

## 8. Database indexes

Indexes are created on the columns most likely to appear in WHERE clauses:

```sql
CREATE INDEX idx_records_date     ON financial_records(date);
CREATE INDEX idx_records_type     ON financial_records(type);
CREATE INDEX idx_records_category ON financial_records(category);
CREATE INDEX idx_records_deleted  ON financial_records(is_deleted);
```

For a small dataset these make no measurable difference, but it demonstrates
awareness that these columns will be filtered frequently and would become
bottlenecks as data grows.

---

## 9. Error response format

All errors use a consistent envelope:

```json
{
  "error": "Short description",
  "detail": "Optional longer explanation",
  "details": { "field_name": ["list of problems"] }
}
```

The field-level `details` object is only present on 422 validation errors.
This mirrors what most frontend validation libraries expect and makes it
straightforward to display per-field error messages to the user.

---

## 10. What I would add next

If this were a real project and not an assessment, the next steps would be:

1. **Token expiry and refresh** — short-lived access tokens plus a
   `POST /api/auth/refresh` endpoint.
2. **Rate limiting** — limit login attempts to prevent brute force.
3. **PostgreSQL migration** — replace SQLite with PostgreSQL for production.
4. **Audit log table** — record who changed what and when, separate from
   the `updated_at` timestamp.
5. **CSV/PDF export** of records filtered by date range.
6. **Email notifications** for large transactions or unusual activity.
