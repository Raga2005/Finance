import uuid
import bcrypt
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required
from ..db import get_db
from ..middleware.auth import require_role
from ..validators import validate_register, validate_update_user

users_bp = Blueprint("users", __name__)


@users_bp.route("/", methods=["GET"])
@jwt_required()
@require_role("admin")
def list_users():
    """List all users. Admin only."""
    db = get_db()
    page = max(1, int(request.args.get("page", 1)))
    per_page = min(50, max(1, int(request.args.get("per_page", 20))))
    offset = (page - 1) * per_page

    total = db.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    users = db.execute(
        "SELECT id, name, email, role, is_active, created_at FROM users ORDER BY created_at DESC LIMIT ? OFFSET ?",
        (per_page, offset),
    ).fetchall()

    return jsonify({
        "users": [dict(u) for u in users],
        "pagination": {
            "page": page,
            "per_page": per_page,
            "total": total,
            "pages": -(-total // per_page),  # ceiling division
        },
    }), 200


@users_bp.route("/", methods=["POST"])
@jwt_required()
@require_role("admin")
def create_user():
    """Create a user with any role. Admin only."""
    data, errors = validate_register(request.get_json(silent=True) or {})
    if errors:
        return jsonify({"error": "Validation failed", "details": errors}), 422

    db = get_db()
    if db.execute("SELECT id FROM users WHERE email = ?", (data["email"],)).fetchone():
        return jsonify({"error": "Email already registered"}), 409

    user_id = str(uuid.uuid4())
    hashed = bcrypt.hashpw(data["password"].encode(), bcrypt.gensalt()).decode()

    db.execute(
        "INSERT INTO users (id, name, email, password, role) VALUES (?, ?, ?, ?, ?)",
        (user_id, data["name"], data["email"], hashed, data["role"]),
    )
    db.commit()

    return jsonify({
        "message": "User created",
        "user": {"id": user_id, "name": data["name"], "email": data["email"], "role": data["role"]},
    }), 201


@users_bp.route("/<user_id>", methods=["GET"])
@jwt_required()
@require_role("admin")
def get_user(user_id):
    db = get_db()
    user = db.execute(
        "SELECT id, name, email, role, is_active, created_at FROM users WHERE id = ?",
        (user_id,)
    ).fetchone()

    if not user:
        return jsonify({"error": "User not found"}), 404

    return jsonify({"user": dict(user)}), 200


@users_bp.route("/<user_id>", methods=["PATCH"])
@jwt_required()
@require_role("admin")
def update_user(user_id):
    """Update name, role, or active status. Admin only."""
    data, errors = validate_update_user(request.get_json(silent=True) or {})
    if errors:
        return jsonify({"error": "Validation failed", "details": errors}), 422

    if not data:
        return jsonify({"error": "No valid fields provided"}), 400

    db = get_db()
    user = db.execute("SELECT id FROM users WHERE id = ?", (user_id,)).fetchone()
    if not user:
        return jsonify({"error": "User not found"}), 404

    set_clause = ", ".join(f"{k} = ?" for k in data)
    values = list(data.values()) + [user_id]
    db.execute(
        f"UPDATE users SET {set_clause}, updated_at = datetime('now') WHERE id = ?",
        values,
    )
    db.commit()

    updated = db.execute(
        "SELECT id, name, email, role, is_active, updated_at FROM users WHERE id = ?",
        (user_id,)
    ).fetchone()

    return jsonify({"message": "User updated", "user": dict(updated)}), 200


@users_bp.route("/<user_id>", methods=["DELETE"])
@jwt_required()
@require_role("admin")
def deactivate_user(user_id):
    """Soft-delete by deactivating the account. Admin only."""
    db = get_db()
    user = db.execute("SELECT id FROM users WHERE id = ?", (user_id,)).fetchone()
    if not user:
        return jsonify({"error": "User not found"}), 404

    db.execute(
        "UPDATE users SET is_active = 0, updated_at = datetime('now') WHERE id = ?",
        (user_id,)
    )
    db.commit()
    return jsonify({"message": "User deactivated"}), 200
