import uuid
import bcrypt
from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from ..db import get_db
from ..validators import validate_register, validate_login

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/register", methods=["POST"])
def register():
    """
    Register a new user.
    Only admins can create analyst or admin accounts (enforced in /users).
    This public endpoint only allows viewer self-registration.
    """
    data, errors = validate_register(request.get_json(silent=True) or {})
    if errors:
        return jsonify({"error": "Validation failed", "details": errors}), 422

    # Public registration is limited to viewer role
    if data["role"] != "viewer":
        return jsonify({
            "error": "Forbidden",
            "detail": "Public registration only allows viewer role. Contact an admin for other roles.",
        }), 403

    db = get_db()
    existing = db.execute("SELECT id FROM users WHERE email = ?", (data["email"],)).fetchone()
    if existing:
        return jsonify({"error": "Email already registered"}), 409

    user_id = str(uuid.uuid4())
    hashed = bcrypt.hashpw(data["password"].encode(), bcrypt.gensalt()).decode()

    db.execute(
        "INSERT INTO users (id, name, email, password, role) VALUES (?, ?, ?, ?, ?)",
        (user_id, data["name"], data["email"], hashed, data["role"]),
    )
    db.commit()

    token = create_access_token(identity=user_id)
    return jsonify({
        "message": "Account created",
        "token": token,
        "user": {"id": user_id, "name": data["name"], "email": data["email"], "role": data["role"]},
    }), 201


@auth_bp.route("/login", methods=["POST"])
def login():
    data, errors = validate_login(request.get_json(silent=True) or {})
    if errors:
        return jsonify({"error": "Validation failed", "details": errors}), 422

    db = get_db()
    user = db.execute(
        "SELECT * FROM users WHERE email = ?", (data["email"],)
    ).fetchone()

    if not user or not bcrypt.checkpw(data["password"].encode(), user["password"].encode()):
        return jsonify({"error": "Invalid email or password"}), 401

    if not user["is_active"]:
        return jsonify({"error": "Account is inactive. Contact an admin."}), 403

    token = create_access_token(identity=user["id"])
    return jsonify({
        "token": token,
        "user": {
            "id": user["id"],
            "name": user["name"],
            "email": user["email"],
            "role": user["role"],
        },
    }), 200


@auth_bp.route("/me", methods=["GET"])
@jwt_required()
def me():
    user_id = get_jwt_identity()
    db = get_db()
    user = db.execute(
        "SELECT id, name, email, role, is_active, created_at FROM users WHERE id = ?",
        (user_id,)
    ).fetchone()

    if not user:
        return jsonify({"error": "User not found"}), 404

    return jsonify({"user": dict(user)}), 200
