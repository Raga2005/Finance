import uuid
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from ..db import get_db
from ..middleware.auth import require_role, require_min_role
from ..validators import validate_record, validate_record_filters

records_bp = Blueprint("records", __name__)


@records_bp.route("/", methods=["GET"])
@jwt_required()
@require_min_role("viewer")
def list_records():
    """
    List financial records with optional filters.
    All roles can view. Supports pagination, date range, type, and category filtering.

    Query params:
        type        - income | expense
        category    - string match (case-insensitive)
        date_from   - YYYY-MM-DD
        date_to     - YYYY-MM-DD
        page        - integer (default 1)
        per_page    - integer (default 20, max 100)
    """
    filters, errors = validate_record_filters(request.args)
    if errors:
        return jsonify({"error": "Validation failed", "details": errors}), 422

    db = get_db()
    conditions = ["r.is_deleted = 0"]
    params = []

    if filters.get("type"):
        conditions.append("r.type = ?")
        params.append(filters["type"])

    if filters.get("category"):
        conditions.append("LOWER(r.category) = LOWER(?)")
        params.append(filters["category"])

    if filters.get("search"):
        conditions.append("(LOWER(r.category) LIKE LOWER(?) OR LOWER(r.notes) LIKE LOWER(?))")
        term = f"%{filters['search']}%"
        params.extend([term, term])

    if filters.get("date_from"):
        conditions.append("r.date >= ?")
        params.append(filters["date_from"])

    if filters.get("date_to"):
        conditions.append("r.date <= ?")
        params.append(filters["date_to"])

    where_clause = " AND ".join(conditions)

    total = db.execute(
        f"SELECT COUNT(*) FROM financial_records r WHERE {where_clause}", params
    ).fetchone()[0]

    offset = (filters["page"] - 1) * filters["per_page"]
    rows = db.execute(
        f"""
        SELECT r.id, r.amount, r.type, r.category, r.date, r.notes,
               r.created_at, r.updated_at, u.name as created_by_name
        FROM financial_records r
        JOIN users u ON r.created_by = u.id
        WHERE {where_clause}
        ORDER BY r.date DESC, r.created_at DESC
        LIMIT ? OFFSET ?
        """,
        params + [filters["per_page"], offset],
    ).fetchall()

    return jsonify({
        "records": [dict(r) for r in rows],
        "pagination": {
            "page": filters["page"],
            "per_page": filters["per_page"],
            "total": total,
            "pages": -(-total // filters["per_page"]),
        },
        "filters_applied": {k: v for k, v in filters.items() if k not in ("page", "per_page")},
    }), 200


@records_bp.route("/<record_id>", methods=["GET"])
@jwt_required()
@require_min_role("viewer")
def get_record(record_id):
    db = get_db()
    row = db.execute(
        """
        SELECT r.*, u.name as created_by_name
        FROM financial_records r
        JOIN users u ON r.created_by = u.id
        WHERE r.id = ? AND r.is_deleted = 0
        """,
        (record_id,)
    ).fetchone()

    if not row:
        return jsonify({"error": "Record not found"}), 404

    return jsonify({"record": dict(row)}), 200


@records_bp.route("/", methods=["POST"])
@jwt_required()
@require_role("admin")
def create_record():
    """Create a financial record. Admin only."""
    data, errors = validate_record(request.get_json(silent=True) or {})
    if errors:
        return jsonify({"error": "Validation failed", "details": errors}), 422

    user_id = get_jwt_identity()
    record_id = str(uuid.uuid4())
    db = get_db()

    db.execute(
        """
        INSERT INTO financial_records (id, amount, type, category, date, notes, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (record_id, data["amount"], data["type"], data["category"],
         data["date"], data["notes"], user_id),
    )
    db.commit()

    created = db.execute(
        "SELECT * FROM financial_records WHERE id = ?", (record_id,)
    ).fetchone()

    return jsonify({"message": "Record created", "record": dict(created)}), 201


@records_bp.route("/<record_id>", methods=["PATCH"])
@jwt_required()
@require_role("admin")
def update_record(record_id):
    """Partial update of a record. Admin only."""
    raw = request.get_json(silent=True) or {}

    # Only validate fields that are actually present
    all_data, errors = validate_record({
        "amount":   raw.get("amount", 1),       # dummy default to pass validation
        "type":     raw.get("type", "income"),
        "category": raw.get("category", "misc"),
        "date":     raw.get("date", "2000-01-01"),
        "notes":    raw.get("notes"),
    })

    # Re-validate only provided fields
    update_data = {}
    re_errors = {}

    if "amount" in raw:
        d, e = validate_record({**raw, "type": "income", "category": "x", "date": "2000-01-01"})
        if e and "amount" in e:
            re_errors["amount"] = e["amount"]
        else:
            update_data["amount"] = float(raw["amount"])

    if "type" in raw:
        if raw["type"] not in ("income", "expense"):
            re_errors["type"] = ["Type must be income or expense"]
        else:
            update_data["type"] = raw["type"]

    if "category" in raw:
        cat = (raw["category"] or "").strip()
        if not cat:
            re_errors["category"] = ["Category cannot be empty"]
        else:
            update_data["category"] = cat

    if "date" in raw:
        from datetime import datetime
        try:
            datetime.strptime(raw["date"], "%Y-%m-%d")
            update_data["date"] = raw["date"]
        except ValueError:
            re_errors["date"] = ["Date must be YYYY-MM-DD"]

    if "notes" in raw:
        update_data["notes"] = (raw["notes"] or "").strip() or None

    if re_errors:
        return jsonify({"error": "Validation failed", "details": re_errors}), 422

    if not update_data:
        return jsonify({"error": "No valid fields provided"}), 400

    db = get_db()
    record = db.execute(
        "SELECT id FROM financial_records WHERE id = ? AND is_deleted = 0", (record_id,)
    ).fetchone()

    if not record:
        return jsonify({"error": "Record not found"}), 404

    set_clause = ", ".join(f"{k} = ?" for k in update_data)
    values = list(update_data.values()) + [record_id]
    db.execute(
        f"UPDATE financial_records SET {set_clause}, updated_at = datetime('now') WHERE id = ?",
        values,
    )
    db.commit()

    updated = db.execute("SELECT * FROM financial_records WHERE id = ?", (record_id,)).fetchone()
    return jsonify({"message": "Record updated", "record": dict(updated)}), 200


@records_bp.route("/<record_id>", methods=["DELETE"])
@jwt_required()
@require_role("admin")
def delete_record(record_id):
    """Soft delete a record. Admin only."""
    db = get_db()
    record = db.execute(
        "SELECT id FROM financial_records WHERE id = ? AND is_deleted = 0", (record_id,)
    ).fetchone()

    if not record:
        return jsonify({"error": "Record not found"}), 404

    db.execute(
        "UPDATE financial_records SET is_deleted = 1, updated_at = datetime('now') WHERE id = ?",
        (record_id,)
    )
    db.commit()
    return jsonify({"message": "Record deleted"}), 200


@records_bp.route("/categories", methods=["GET"])
@jwt_required()
@require_min_role("viewer")
def list_categories():
    """Return all distinct categories in the system."""
    db = get_db()
    rows = db.execute(
        "SELECT DISTINCT category FROM financial_records WHERE is_deleted = 0 ORDER BY category"
    ).fetchall()
    return jsonify({"categories": [r["category"] for r in rows]}), 200
