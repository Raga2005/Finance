from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required
from ..db import get_db
from ..middleware.auth import require_min_role

dashboard_bp = Blueprint("dashboard", __name__)


@dashboard_bp.route("/summary", methods=["GET"])
@jwt_required()
@require_min_role("viewer")
def summary():
    """
    Overall financial summary.
    Returns: total_income, total_expenses, net_balance, record_count.

    Optional query params:
        date_from - YYYY-MM-DD
        date_to   - YYYY-MM-DD
    """
    db = get_db()
    conditions, params = _build_date_conditions(request.args)

    row = db.execute(
        f"""
        SELECT
            COALESCE(SUM(CASE WHEN type = 'income'  THEN amount ELSE 0 END), 0) as total_income,
            COALESCE(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 0) as total_expenses,
            COUNT(*) as record_count
        FROM financial_records
        WHERE is_deleted = 0 {conditions}
        """,
        params,
    ).fetchone()

    total_income = round(row["total_income"], 2)
    total_expenses = round(row["total_expenses"], 2)

    return jsonify({
        "summary": {
            "total_income": total_income,
            "total_expenses": total_expenses,
            "net_balance": round(total_income - total_expenses, 2),
            "record_count": row["record_count"],
        }
    }), 200


@dashboard_bp.route("/by-category", methods=["GET"])
@jwt_required()
@require_min_role("viewer")
def by_category():
    """
    Breakdown of income and expenses by category.
    Useful for pie/bar charts on the dashboard.
    """
    db = get_db()
    conditions, params = _build_date_conditions(request.args)

    rows = db.execute(
        f"""
        SELECT
            category,
            type,
            ROUND(SUM(amount), 2) as total,
            COUNT(*) as count
        FROM financial_records
        WHERE is_deleted = 0 {conditions}
        GROUP BY category, type
        ORDER BY total DESC
        """,
        params,
    ).fetchall()

    # Shape into {category: {income: X, expense: Y}} for easy frontend consumption
    result = {}
    for row in rows:
        cat = row["category"]
        if cat not in result:
            result[cat] = {"category": cat, "income": 0.0, "expense": 0.0, "total_transactions": 0}
        result[cat][row["type"]] = row["total"]
        result[cat]["total_transactions"] += row["count"]

    return jsonify({"by_category": list(result.values())}), 200


@dashboard_bp.route("/monthly-trends", methods=["GET"])
@jwt_required()
@require_min_role("analyst")  # Trend data is analyst+ only
def monthly_trends():
    """
    Monthly income and expense totals for the past N months.
    Analyst and admin only (more detailed insight).

    Query params:
        months - how many months of history (default 12, max 36)
    """
    db = get_db()
    try:
        months = min(36, max(1, int(request.args.get("months", 12))))
    except ValueError:
        months = 12

    rows = db.execute(
        """
        SELECT
            strftime('%Y-%m', date) as month,
            ROUND(SUM(CASE WHEN type = 'income'  THEN amount ELSE 0 END), 2) as income,
            ROUND(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 2) as expenses,
            COUNT(*) as transactions
        FROM financial_records
        WHERE is_deleted = 0
          AND date >= date('now', ? || ' months')
        GROUP BY month
        ORDER BY month ASC
        """,
        (f"-{months}",),
    ).fetchall()

    trends = [dict(r) for r in rows]
    for t in trends:
        t["net"] = round(t["income"] - t["expenses"], 2)

    return jsonify({"monthly_trends": trends, "months_requested": months}), 200


@dashboard_bp.route("/recent", methods=["GET"])
@jwt_required()
@require_min_role("viewer")
def recent_activity():
    """
    Most recent financial records for the activity feed.
    Query params:
        limit - number of records (default 10, max 50)
    """
    db = get_db()
    try:
        limit = min(50, max(1, int(request.args.get("limit", 10))))
    except ValueError:
        limit = 10

    rows = db.execute(
        """
        SELECT r.id, r.amount, r.type, r.category, r.date, r.notes,
               r.created_at, u.name as created_by_name
        FROM financial_records r
        JOIN users u ON r.created_by = u.id
        WHERE r.is_deleted = 0
        ORDER BY r.created_at DESC
        LIMIT ?
        """,
        (limit,),
    ).fetchall()

    return jsonify({"recent": [dict(r) for r in rows]}), 200


@dashboard_bp.route("/weekly-summary", methods=["GET"])
@jwt_required()
@require_min_role("viewer")
def weekly_summary():
    """Income vs expenses for each of the last 4 weeks."""
    db = get_db()

    rows = db.execute(
        """
        SELECT
            strftime('%W-%Y', date) as week_key,
            date(date, 'weekday 0', '-6 days') as week_start,
            ROUND(SUM(CASE WHEN type = 'income'  THEN amount ELSE 0 END), 2) as income,
            ROUND(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 2) as expenses
        FROM financial_records
        WHERE is_deleted = 0
          AND date >= date('now', '-28 days')
        GROUP BY week_key
        ORDER BY week_start ASC
        """
    ).fetchall()

    weeks = [dict(r) for r in rows]
    for w in weeks:
        w["net"] = round(w["income"] - w["expenses"], 2)
        del w["week_key"]

    return jsonify({"weekly_summary": weeks}), 200


# ── Helpers ────────────────────────────────────────────────────────────────────

def _build_date_conditions(args):
    """Build WHERE clause fragment and params from date_from/date_to query args."""
    conditions = ""
    params = []

    if args.get("date_from"):
        conditions += " AND date >= ?"
        params.append(args["date_from"])

    if args.get("date_to"):
        conditions += " AND date <= ?"
        params.append(args["date_to"])

    return conditions, params
