import sqlite3
import os
from flask import g

DB_PATH = os.environ.get("DB_PATH", "finance.db")


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH, detect_types=sqlite3.PARSE_DECLTYPES)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(e=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db(app):
    with app.app_context():
        db = sqlite3.connect(DB_PATH)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys = ON")
        _create_tables(db)
        _seed_admin(db)
        db.close()

    app.teardown_appcontext(close_db)


def _create_tables(db):
    db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id          TEXT PRIMARY KEY,
            name        TEXT NOT NULL,
            email       TEXT UNIQUE NOT NULL,
            password    TEXT NOT NULL,
            role        TEXT NOT NULL CHECK(role IN ('viewer', 'analyst', 'admin')),
            is_active   INTEGER NOT NULL DEFAULT 1,
            created_at  TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS financial_records (
            id          TEXT PRIMARY KEY,
            amount      REAL NOT NULL CHECK(amount > 0),
            type        TEXT NOT NULL CHECK(type IN ('income', 'expense')),
            category    TEXT NOT NULL,
            date        TEXT NOT NULL,
            notes       TEXT,
            created_by  TEXT NOT NULL REFERENCES users(id),
            is_deleted  INTEGER NOT NULL DEFAULT 0,
            created_at  TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE INDEX IF NOT EXISTS idx_records_date     ON financial_records(date);
        CREATE INDEX IF NOT EXISTS idx_records_type     ON financial_records(type);
        CREATE INDEX IF NOT EXISTS idx_records_category ON financial_records(category);
        CREATE INDEX IF NOT EXISTS idx_records_deleted  ON financial_records(is_deleted);
    """)
    db.commit()


def _seed_admin(db):
    """Create a default admin user if none exists."""
    import bcrypt, uuid
    existing = db.execute("SELECT id FROM users WHERE role = 'admin'").fetchone()
    if existing:
        return

    admin_id = str(uuid.uuid4())
    hashed = bcrypt.hashpw(b"admin123", bcrypt.gensalt()).decode()
    db.execute(
        "INSERT INTO users (id, name, email, password, role) VALUES (?, ?, ?, ?, ?)",
        (admin_id, "Admin User", "admin@finance.local", hashed, "admin"),
    )
    db.commit()
    print(f"[SEED] Default admin created — email: admin@finance.local  password: admin123")
