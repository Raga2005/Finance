"""
Input validators.
Each validator returns (data, errors) where errors is None on success.
"""

from datetime import datetime
from typing import Optional


def _collect(errors, field, msg):
    errors.setdefault(field, []).append(msg)


# ── Auth ───────────────────────────────────────────────────────────────────────

def validate_register(data: dict):
    errors = {}
    name = (data.get("name") or "").strip()
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""
    role = data.get("role", "viewer")

    if not name:
        _collect(errors, "name", "Name is required")
    elif len(name) < 2:
        _collect(errors, "name", "Name must be at least 2 characters")

    if not email:
        _collect(errors, "email", "Email is required")
    elif "@" not in email or "." not in email.split("@")[-1]:
        _collect(errors, "email", "Invalid email format")

    if not password:
        _collect(errors, "password", "Password is required")
    elif len(password) < 6:
        _collect(errors, "password", "Password must be at least 6 characters")

    if role not in ("viewer", "analyst", "admin"):
        _collect(errors, "role", "Role must be viewer, analyst, or admin")

    if errors:
        return None, errors

    return {"name": name, "email": email, "password": password, "role": role}, None


def validate_login(data: dict):
    errors = {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    if not email:
        _collect(errors, "email", "Email is required")
    if not password:
        _collect(errors, "password", "Password is required")

    if errors:
        return None, errors
    return {"email": email, "password": password}, None


# ── Users ──────────────────────────────────────────────────────────────────────

def validate_update_user(data: dict):
    errors = {}
    allowed = {}

    if "name" in data:
        name = (data["name"] or "").strip()
        if len(name) < 2:
            _collect(errors, "name", "Name must be at least 2 characters")
        else:
            allowed["name"] = name

    if "role" in data:
        if data["role"] not in ("viewer", "analyst", "admin"):
            _collect(errors, "role", "Role must be viewer, analyst, or admin")
        else:
            allowed["role"] = data["role"]

    if "is_active" in data:
        if not isinstance(data["is_active"], bool):
            _collect(errors, "is_active", "is_active must be a boolean")
        else:
            allowed["is_active"] = 1 if data["is_active"] else 0

    if errors:
        return None, errors
    return allowed, None


# ── Financial records ──────────────────────────────────────────────────────────

VALID_TYPES = ("income", "expense")

def validate_record(data: dict):
    errors = {}

    # amount
    amount = data.get("amount")
    if amount is None:
        _collect(errors, "amount", "Amount is required")
    else:
        try:
            amount = float(amount)
            if amount <= 0:
                _collect(errors, "amount", "Amount must be greater than 0")
        except (TypeError, ValueError):
            _collect(errors, "amount", "Amount must be a number")

    # type
    record_type = data.get("type")
    if not record_type:
        _collect(errors, "type", "Type is required")
    elif record_type not in VALID_TYPES:
        _collect(errors, "type", f"Type must be one of: {', '.join(VALID_TYPES)}")

    # category
    category = (data.get("category") or "").strip()
    if not category:
        _collect(errors, "category", "Category is required")
    elif len(category) > 100:
        _collect(errors, "category", "Category must be under 100 characters")

    # date
    date_str = data.get("date")
    if not date_str:
        _collect(errors, "date", "Date is required")
    else:
        try:
            datetime.strptime(date_str, "%Y-%m-%d")
        except ValueError:
            _collect(errors, "date", "Date must be in YYYY-MM-DD format")

    # notes (optional)
    notes = (data.get("notes") or "").strip() or None
    if notes and len(notes) > 500:
        _collect(errors, "notes", "Notes must be under 500 characters")

    if errors:
        return None, errors

    return {
        "amount": round(amount, 2),
        "type": record_type,
        "category": category,
        "date": date_str,
        "notes": notes,
    }, None


def validate_record_filters(args: dict):
    """Parse and validate query params for record listing."""
    errors = {}
    filters = {}

    if args.get("type"):
        if args["type"] not in VALID_TYPES:
            _collect(errors, "type", f"Type must be one of: {', '.join(VALID_TYPES)}")
        else:
            filters["type"] = args["type"]

    if args.get("category"):
        filters["category"] = args["category"].strip()

    if args.get("search"):
        s = args["search"].strip()
        if len(s) > 100:
            _collect(errors, "search", "Search term must be under 100 characters")
        else:
            filters["search"] = s

    if args.get("date_from"):
        try:
            datetime.strptime(args["date_from"], "%Y-%m-%d")
            filters["date_from"] = args["date_from"]
        except ValueError:
            _collect(errors, "date_from", "date_from must be YYYY-MM-DD")

    if args.get("date_to"):
        try:
            datetime.strptime(args["date_to"], "%Y-%m-%d")
            filters["date_to"] = args["date_to"]
        except ValueError:
            _collect(errors, "date_to", "date_to must be YYYY-MM-DD")

    if filters.get("date_from") and filters.get("date_to"):
        if filters["date_from"] > filters["date_to"]:
            _collect(errors, "date_range", "date_from must be before date_to")

    # Pagination
    try:
        filters["page"] = max(1, int(args.get("page", 1)))
    except ValueError:
        filters["page"] = 1

    try:
        filters["per_page"] = min(100, max(1, int(args.get("per_page", 20))))
    except ValueError:
        filters["per_page"] = 20

    if errors:
        return None, errors
    return filters, None
