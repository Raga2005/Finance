from flask import Flask
from flask_jwt_extended import JWTManager
from flask_cors import CORS
from .db import init_db
from .routes.auth import auth_bp
from .routes.users import users_bp
from .routes.records import records_bp
from .routes.dashboard import dashboard_bp
from .utils.error_handlers import register_error_handlers
import os


def create_app(config=None):
    app = Flask(__name__)

    app.config["JWT_SECRET_KEY"] = os.environ.get("JWT_SECRET_KEY", "dev-secret-change-in-production")
    app.config["JWT_ACCESS_TOKEN_EXPIRES"] = False  # Simplified for assessment

    if config:
        app.config.update(config)

    JWTManager(app)
    CORS(app, origins="*")
    init_db(app)
    register_error_handlers(app)

    app.register_blueprint(auth_bp, url_prefix="/api/auth")
    app.register_blueprint(users_bp, url_prefix="/api/users")
    app.register_blueprint(records_bp, url_prefix="/api/records")
    app.register_blueprint(dashboard_bp, url_prefix="/api/dashboard")

    return app
