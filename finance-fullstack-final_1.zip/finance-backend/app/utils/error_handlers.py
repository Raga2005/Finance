from flask import jsonify
from flask_jwt_extended.exceptions import NoAuthorizationError, InvalidHeaderError
from jwt.exceptions import ExpiredSignatureError, DecodeError


def register_error_handlers(app):

    @app.errorhandler(400)
    def bad_request(e):
        return jsonify({"error": "Bad request", "detail": str(e)}), 400

    @app.errorhandler(404)
    def not_found(e):
        return jsonify({"error": "Not found"}), 404

    @app.errorhandler(405)
    def method_not_allowed(e):
        return jsonify({"error": "Method not allowed"}), 405

    @app.errorhandler(500)
    def internal_error(e):
        return jsonify({"error": "Internal server error"}), 500

    @app.errorhandler(NoAuthorizationError)
    def missing_token(e):
        return jsonify({"error": "Authentication required", "detail": "Provide a Bearer token"}), 401

    @app.errorhandler(InvalidHeaderError)
    def invalid_header(e):
        return jsonify({"error": "Invalid authorization header"}), 401

    @app.errorhandler(ExpiredSignatureError)
    def expired_token(e):
        return jsonify({"error": "Token has expired"}), 401

    @app.errorhandler(DecodeError)
    def invalid_token(e):
        return jsonify({"error": "Invalid token"}), 401
