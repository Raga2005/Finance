"""
Access control middleware.

Usage in routes:
    @records_bp.route("/", methods=["POST"])
    @jwt_required()
    @require_role("admin", "analyst")
    def create_record():
        ...

Roles hierarchy:
    viewer  → read-only access to records and dashboard
    analyst → viewer + can access detailed insights
    admin   → full access including user management and record mutations
"""

from functools import wraps
from flask import jsonify
from flask_jwt_extended import get_jwt_identity
from ..db import get_db


ROLE_HIERARCHY = {
    "viewer": 1,
    "analyst": 2,
    "admin": 3,
}


def require_role(*allowed_roles):
    """Decorator that restricts a route to users with one of the given roles."""
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            user_id = get_jwt_identity()
            db = get_db()
            user = db.execute(
                "SELECT role, is_active FROM users WHERE id = ?", (user_id,)
            ).fetchone()

            if not user:
                return jsonify({"error": "User not found"}), 404

            if not user["is_active"]:
                return jsonify({"error": "Account is inactive"}), 403

            if user["role"] not in allowed_roles:
                return jsonify({
                    "error": "Forbidden",
                    "detail": f"This action requires one of: {', '.join(allowed_roles)}",
                }), 403

            return fn(*args, **kwargs)
        return wrapper
    return decorator


def require_min_role(min_role):
    """Decorator using role hierarchy — allows the given role and above."""
    min_level = ROLE_HIERARCHY[min_role]

    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            user_id = get_jwt_identity()
            db = get_db()
            user = db.execute(
                "SELECT role, is_active FROM users WHERE id = ?", (user_id,)
            ).fetchone()

            if not user:
                return jsonify({"error": "User not found"}), 404

            if not user["is_active"]:
                return jsonify({"error": "Account is inactive"}), 403

            if ROLE_HIERARCHY.get(user["role"], 0) < min_level:
                return jsonify({
                    "error": "Forbidden",
                    "detail": f"Minimum required role: {min_role}",
                }), 403

            return fn(*args, **kwargs)
        return wrapper
    return decorator
